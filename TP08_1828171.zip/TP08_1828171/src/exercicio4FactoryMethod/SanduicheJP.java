package exercicio4FactoryMethod;

public class SanduicheJP extends Sanduiche{
	
	protected SanduicheJP() {
		super("Franc�s", "Mussarela", "De Frango", "Com Verdura");
	}
	
}
