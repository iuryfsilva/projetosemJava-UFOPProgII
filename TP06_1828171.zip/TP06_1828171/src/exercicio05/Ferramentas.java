package exercicio05;

public interface Ferramentas {
	
	public Animal[] filtraEspecie ( Animal completo[], String especieFiltrar);
	public String[] classificaEspecies ( Animal completo[]);

}
