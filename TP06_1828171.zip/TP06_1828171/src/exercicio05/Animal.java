package exercicio05;

public interface Animal {

	public String getNomeEspecie();
	public String getNomeAnimal();
	
}
