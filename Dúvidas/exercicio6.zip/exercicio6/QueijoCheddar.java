package exercicio6;

public class QueijoCheddar implements QueijoIF {

	@Override
	public String toString() {
		return QueijoCheddar.class.getSimpleName();
	}
	
}
