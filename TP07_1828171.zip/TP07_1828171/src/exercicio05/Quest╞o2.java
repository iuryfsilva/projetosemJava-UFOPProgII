package exercicio05;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Quest�o2 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		//boolean controle = true;
		double r = 0;
		int x = 0;
		int y = 0;
		System.out.println("Eu sei dividir! "); 
		do{
			try {
				System.out.println("Informe o primeiro valor: ");
				x = teclado.nextInt();//receber valores de tipos diferentes de int
			} catch (InputMismatchException excecao) {
				System.out.println("ERRO: O tipo do valor Deve ser INTEIRO!");
				//continue;
			} catch (ArithmeticException excecao) {
				System.out.println("ERRO: O valor de y n�o pode ser 0!");
				//continue;
			} catch (Exception e) {
				System.out.println("ERRO: Erro inesperado!");
				//continue;
			}	
			try {
				System.out.println("Informe o segundo valor: ");
				y = teclado.nextInt();
			} catch (InputMismatchException excecao) {
				System.out.println("ERRO: O tipo do valor Deve ser INTEIRO!");
				//continue;
			} catch (ArithmeticException excecao) {
				System.out.println("ERRO: O valor de y n�o pode ser 0!");
				//continue;
			} catch (Exception e) {
				System.out.println("ERRO: Erro inesperado!");
				//continue;
			}
			try {
				r = (x / y); // problema da divis�o por 0
			} catch (InputMismatchException excecao) {
				System.out.println("ERRO: O tipo do valor Deve ser INTEIRO!");
				//continue;
			} catch (ArithmeticException excecao) {
				System.out.println("ERRO: O valor de y n�o pode ser 0!");
				//continue;
			} catch (Exception e) {
				System.out.println("ERRO: Erro inesperado!");
				//continue;
			}
			System.out.println("O resultado da Divisao �: " + r);
			
		}while(r == 0 && x != 0 );
		teclado.close();
	}

	
}
