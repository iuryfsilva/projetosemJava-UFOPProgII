package exercicio6;

public class QueijoMussarela implements QueijoIF {

	@Override
	public String toString() {
		return QueijoMussarela.class.getSimpleName();
	}

}
