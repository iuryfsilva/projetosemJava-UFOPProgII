package exercicio6;

public interface SanduichesIngredientFactory {

	public Sanduiche factorySanduiche(PaoIF pao, QueijoIF queijo, PresuntoIF presunto, SaladaIF salada);
		
}
