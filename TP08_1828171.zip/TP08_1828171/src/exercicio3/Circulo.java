package exercicio3;

public class Circulo implements FormaGeometrica{

	@Override
	public void desenhar() {
		System.out.println(Circulo.class.getSimpleName());		
	}

}
