package exercicio4FactoryMethod;

public class SanduicheRT extends Sanduiche{
	
	protected SanduicheRT() {
		super("Bola", "Cheddar", "De Peru", "Sem Verdura");
	}
	
}
