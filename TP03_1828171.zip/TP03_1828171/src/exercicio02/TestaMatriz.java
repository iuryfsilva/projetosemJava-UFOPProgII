package exercicio02;

public class TestaMatriz {

	public static void main(String[] args) {
		
		Matriz matriz1 = new Matriz(3,3);
		matriz1.executaTestes();
		
	}

}
