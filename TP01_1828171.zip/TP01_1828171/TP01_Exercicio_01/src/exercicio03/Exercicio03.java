package exercicio03;

public class Exercicio03 {
	
	public static void main(String[] args) {
		CalculaSequencia sequencia = new CalculaSequencia();
		sequencia.imprimeSequencia();
	}
}
