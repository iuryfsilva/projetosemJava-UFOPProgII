package exercicio3;

public class Triangulo implements FormaGeometrica{

	@Override
	public void desenhar() {
		System.out.println(Triangulo.class.getSimpleName());
	}

}
