package exercicio3;

public class Quadrado implements FormaGeometrica{

	@Override
	public void desenhar() {
		System.out.println(Quadrado.class.getSimpleName());
	}

}
