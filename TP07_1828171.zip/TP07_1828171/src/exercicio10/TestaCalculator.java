package exercicio10;

public class TestaCalculator {

	public static void main(String[] args) {

		Calculator calculadora = new Calculator();
		
		calculadora.execultaCalculadora();
		
	}

}
