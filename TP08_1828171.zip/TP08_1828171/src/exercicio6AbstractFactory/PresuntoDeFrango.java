package exercicio6AbstractFactory;

public class PresuntoDeFrango implements PresuntoIF {

	@Override
	public String toString() {
		return PresuntoDeFrango.class.getSimpleName();
	}

}
