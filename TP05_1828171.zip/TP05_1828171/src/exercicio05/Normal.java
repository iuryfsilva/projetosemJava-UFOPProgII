package exercicio05;

public class Normal extends Ingresso{

	public void imprimeIngressoNormal(){
		System.out.println("Ingresso Normal");
	}
	
}
