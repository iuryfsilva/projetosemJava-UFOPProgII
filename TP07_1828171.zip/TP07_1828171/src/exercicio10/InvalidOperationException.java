package exercicio10;

public class InvalidOperationException extends Exception {

}
