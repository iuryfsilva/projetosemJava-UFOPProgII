package exercicio06;

public class Pobre extends Pessoa{
	
	public void trabalha() {
		System.out.println("Trabalhando....");
	}
	
}
