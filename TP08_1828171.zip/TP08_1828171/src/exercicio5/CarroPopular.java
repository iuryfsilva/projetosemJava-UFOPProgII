package exercicio5;

public abstract class CarroPopular {

	public abstract void exibirInfoPopular();

}
