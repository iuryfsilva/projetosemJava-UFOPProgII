package exercicio6AbstractFactory;

public class ComVerdura implements SaladaIF {

	@Override
	public String toString() {
		return ComVerdura.class.getSimpleName() + ".";
	}

}
