package exercicio6AbstractFactory;

public interface PaoIF {
	public String toString();
}
