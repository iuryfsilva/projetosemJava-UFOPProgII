package exercicio6;

public class SanduichesIngredientFactoryJP implements SanduichesIngredientFactory{

	@Override
	public Sanduiche factorySanduiche(PaoIF pao, QueijoIF queijo, PresuntoIF presunto, SaladaIF salada) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String toString() {
		return SanduichesIngredientFactoryJP.class.getSimpleName();
	}

}
