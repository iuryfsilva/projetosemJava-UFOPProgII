package exercicio6AbstractFactory;

public class QueijoCheddar implements QueijoIF {

	@Override
	public String toString() {
		return QueijoCheddar.class.getSimpleName();
	}
	
}
