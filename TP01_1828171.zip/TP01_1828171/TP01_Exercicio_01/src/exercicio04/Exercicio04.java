package exercicio04;

public class Exercicio04 {

	public static void main(String[] args) {
		
		Metodos04 funcao = new Metodos04();
		funcao.execultar();
		
	}
	
}
