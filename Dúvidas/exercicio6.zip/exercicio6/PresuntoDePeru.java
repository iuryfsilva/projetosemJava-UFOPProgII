package exercicio6;

public class PresuntoDePeru implements PresuntoIF {

	@Override
	public String toString() {
		return PresuntoDePeru.class.getSimpleName();
	}
	
}
