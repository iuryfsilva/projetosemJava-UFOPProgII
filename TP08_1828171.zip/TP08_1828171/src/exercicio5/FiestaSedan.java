package exercicio5;

public class FiestaSedan extends CarroSedan{

	@Override
	public void exibirInfoSedan() {
		System.out.println("Marca: Ford | Modelo: Fiesta Sedan | Categoria: Sedan");				
	}

}
