package exercicio6AbstractFactory;

public class PaoBola implements PaoIF {
	
	@Override
	public String toString() {
		return PaoBola.class.getSimpleName();
	}
	
}
