package exercicio3;

public interface FormaGeometrica {

	public abstract void desenhar();
	
}
