package exercicio7;

public interface SomadorEsperado {

	int somaVetor(int[] vetor);
	
}
