package exercicio02;

public class Exercicio02 {
	
	public static void main(String[] args) {
		
		Metodos02 funcao = new Metodos02();
		funcao.execultar();
		
	}
	
}
