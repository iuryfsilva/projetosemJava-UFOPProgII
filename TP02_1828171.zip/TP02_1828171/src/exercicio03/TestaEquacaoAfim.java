package exercicio03;

public class TestaEquacaoAfim {

	public static void main(String[] args) {

		EquacaoAfim reta1 = new EquacaoAfim();
		reta1.representaReta();
		
	}

}
