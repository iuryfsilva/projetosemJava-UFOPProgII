package exercicio5;

public class Palio extends CarroPopular{

	@Override
	public void exibirInfoPopular() {
		System.out.println("Marca: Fiat | Modelo: Palio        | Categoria: Popular");	
	}

}
