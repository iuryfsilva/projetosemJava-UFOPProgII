package exercicio5;

public abstract class CarroSedan {

	public abstract void exibirInfoSedan();
	
}
