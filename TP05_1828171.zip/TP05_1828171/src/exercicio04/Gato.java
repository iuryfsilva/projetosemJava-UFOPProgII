package exercicio04;

public class Gato extends Animal{

	public String mia() {
		return "Miandonya......nyau";
	}
	
}
