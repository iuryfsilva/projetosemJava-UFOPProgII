package exercicio6;

import java.util.Scanner;

public class TestaSanduicheFactory {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		System.out.println("Informe o tipo de sanduiche conforme a tabela do enunciado da quest�o: ");
		String escolha = teclado.next();

		Sanduiche meuSanduiche = Lanchonete.factorySanduiche(escolha);
		System.out.println(meuSanduiche);
		
		teclado.close();
	}

}
