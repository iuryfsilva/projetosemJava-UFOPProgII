package exercicio6AbstractFactory;

public interface QueijoIF {
	public String toString();
}
