package exercicio04;

public class TestaPais {

	public static void main(String[] args) {
		
		Pais testePais = new Pais();
		testePais.execultaPais();
		
	}

}
