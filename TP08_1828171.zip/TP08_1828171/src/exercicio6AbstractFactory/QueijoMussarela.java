package exercicio6AbstractFactory;

public class QueijoMussarela implements QueijoIF {

	@Override
	public String toString() {
		return QueijoMussarela.class.getSimpleName();
	}

}
