package exercicio02;
import java.util.Scanner;

public class Exercicio02 {

	
	
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Informe o tamanho do vetor: ");
		int tamanho = teclado.nextInt();
		
		int vetorTeste[] = new int[tamanho];
		
		Metodos02 funcao = new Metodos02();
		funcao.preencheVetor(vetorTeste);
		funcao.numerosPrimos(vetorTeste);
		
	}
	
}
