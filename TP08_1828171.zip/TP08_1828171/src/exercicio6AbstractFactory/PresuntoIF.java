package exercicio6AbstractFactory;

public interface PresuntoIF {
	public String toString();
}
