package exercicio04;

public class Exercicio04 {

	public static void main(String[] args) {

		long dados[][] = new long[2][4];
		
		Metodos04 funcao = new Metodos04();
		
		funcao.preencheMatriz(dados);
		funcao.imprimeMatriz(dados);
		funcao.maiorCRcurso(dados);
		
	}
	
}
