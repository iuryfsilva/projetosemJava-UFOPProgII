package exercicio6AbstractFactory;

public class PresuntoDePeru implements PresuntoIF {

	@Override
	public String toString() {
		return PresuntoDePeru.class.getSimpleName();
	}
	
}
