package exercicio6;

public class PaoIntegral implements PaoIF{

	@Override
	public String toString() {
		return PaoIntegral.class.getSimpleName();
	}
	
}
