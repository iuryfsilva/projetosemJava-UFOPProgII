package exercicio6AbstractFactory;

public interface SaladaIF {
	public String toString();
}
