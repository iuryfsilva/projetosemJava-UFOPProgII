package exercicio6AbstractFactory;

public class PaoFrances implements PaoIF {
	
	@Override
	public String toString() {
		return PaoFrances.class.getSimpleName();
	}
	
}
