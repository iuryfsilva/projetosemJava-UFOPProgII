package exercicio5;

public class Siena extends CarroSedan{

	@Override
	public void exibirInfoSedan() {
		System.out.println("Marca: Fiat | Modelo: Siena        | Categoria: Sedan");		
	}

}
