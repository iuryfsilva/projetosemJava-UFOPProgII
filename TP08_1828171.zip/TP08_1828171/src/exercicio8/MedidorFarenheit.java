package exercicio8;

import java.util.Random;

public class MedidorFarenheit {

	public double getTemperaturaFarenheit() {
		return new Random().nextDouble()*100;//simulando o termometro
	}
	
}
