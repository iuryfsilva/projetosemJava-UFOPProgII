package exercicio6;

public interface PresuntoIF {

}
