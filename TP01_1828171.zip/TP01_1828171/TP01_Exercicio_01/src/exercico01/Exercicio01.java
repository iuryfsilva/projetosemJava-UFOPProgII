package exercico01;

public class Exercicio01 {

	public static void main(String[] args) {
				
		Metodos01 funcao = new Metodos01();
		funcao.execultar();
		
	}
	
}
