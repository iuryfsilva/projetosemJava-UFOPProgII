package exercicio6AbstractFactory;

public class SemVerdura implements SaladaIF {

	@Override
	public String toString() {
		return SemVerdura.class.getSimpleName() + ".";
	}
	
}
