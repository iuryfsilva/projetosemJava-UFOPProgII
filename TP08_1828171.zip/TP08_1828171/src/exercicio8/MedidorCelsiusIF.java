package exercicio8;

public interface MedidorCelsiusIF {

	public double medirTemperatura();
	
}
