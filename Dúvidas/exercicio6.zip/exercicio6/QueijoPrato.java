package exercicio6;

public class QueijoPrato implements QueijoIF {

	@Override
	public String toString() {
		return QueijoPrato.class.getSimpleName();
	}

}
