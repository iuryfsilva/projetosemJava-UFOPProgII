package exercicio09;

public class IlustraRelancamentoExcecao {

	public static void main(String[] args) {

		System.out.println("Inicio do main");
		someMethod(5);
		System.out.println("Fim do main");
		
	}
	
	static void someMethod(int valorA) throws ArithmeticException{
		System.out.println("Inicio do metodo1");
		System.out.println(someMethod2(valorA, 0));
		System.out.println("Fim do metodo1");
	}
	static float someMethod2(int a, int b) throws ArithmeticException{
		System.out.println("Inicio do metodo2");
		float resultado = a/b;
		System.out.println("Fim do metodo2");
		return resultado;	
	}
}
