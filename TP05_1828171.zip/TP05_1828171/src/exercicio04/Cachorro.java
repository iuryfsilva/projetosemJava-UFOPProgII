package exercicio04;

public class Cachorro extends Animal {

	public String late() {
		return "Latindouuuuuuouuuuuuu.........";
	}
	
}
