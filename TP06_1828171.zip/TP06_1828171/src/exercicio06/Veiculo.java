package exercicio06;

public abstract class Veiculo {

	abstract public float acelerar(float velocidade);
	abstract public void parar(); 
	
}
