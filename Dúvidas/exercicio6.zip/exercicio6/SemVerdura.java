package exercicio6;

public class SemVerdura implements SaladaIF {

	@Override
	public String toString() {
		return SemVerdura.class.getSimpleName();
	}
	
}
