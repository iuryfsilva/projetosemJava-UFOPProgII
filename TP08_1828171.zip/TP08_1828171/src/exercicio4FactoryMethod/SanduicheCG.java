package exercicio4FactoryMethod;

public class SanduicheCG extends Sanduiche{

	protected SanduicheCG() {
		super("Integral", "Prato", "De Peru", "Sem Verdura");
	}
	
}
