package exercicio6;

public interface SaladaIF {

}
