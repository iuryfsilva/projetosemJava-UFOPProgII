package exercicio01;

public class TestaCalculadora {

	public static void main(String[] args) {
		
		CalculadoraComplexos calculadoraTeste = new CalculadoraComplexos();
		calculadoraTeste.execultaCalculadora();
		
	}

}
