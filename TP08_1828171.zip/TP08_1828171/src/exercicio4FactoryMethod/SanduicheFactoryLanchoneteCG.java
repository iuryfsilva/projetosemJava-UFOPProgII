package exercicio4FactoryMethod;

public class SanduicheFactoryLanchoneteCG extends SanduicheFactory{

	@Override
	public void montarSanduiche(String tipo) {
		
	}

}
