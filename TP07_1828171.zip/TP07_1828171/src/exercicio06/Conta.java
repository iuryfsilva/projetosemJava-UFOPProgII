package exercicio06;

public class Conta {

}
