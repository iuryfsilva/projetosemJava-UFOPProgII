package exercicio04;

public interface IMidia {
	public String getTipo();
	public String getDetalhes();
}
