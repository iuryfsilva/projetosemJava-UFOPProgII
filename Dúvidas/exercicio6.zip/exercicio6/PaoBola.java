package exercicio6;

public class PaoBola implements PaoIF {
	
	@Override
	public String toString() {
		return PaoBola.class.getSimpleName();
	}
	
}
