package exercicio5;

public class Fiesta extends CarroPopular{

	@Override
	public void exibirInfoPopular() {
		System.out.println("Marca: Ford | Modelo: Fiesta       | Categoria: Popular");		
	}

}
