package exercicio02;
import exercicio01.CalculadoraComplexos;

public class TestaCalculadoraComplexos {

	public static void main(String[] args) {
		
		CalculadoraComplexos calculadoraTeste = new CalculadoraComplexos();
		calculadoraTeste.execultaCalculadoraComplexos();
		//calculadoraTeste.execultaCalculadora();
		
	}
}
