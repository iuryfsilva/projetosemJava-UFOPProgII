package exercicio06;

public class Miseravel extends Pessoa{

	public void mendiga() {
		System.out.println("Mendigando....");
	}
	
}
