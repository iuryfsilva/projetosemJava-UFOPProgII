package exercicio06;

public class ContaExcecao extends Exception {

}
