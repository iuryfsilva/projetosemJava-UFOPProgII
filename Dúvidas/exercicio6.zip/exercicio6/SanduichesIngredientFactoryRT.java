package exercicio6;

public class SanduichesIngredientFactoryRT implements SanduichesIngredientFactory{

	@Override
	public Sanduiche factorySanduiche(PaoIF pao, QueijoIF queijo, PresuntoIF presunto, SaladaIF salada) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String toString() {
		return SanduichesIngredientFactoryRT.class.getSimpleName();
	}

}
