package exercicio6;

public class PresuntoDeFrango implements PresuntoIF {

	@Override
	public String toString() {
		return PresuntoDeFrango.class.getSimpleName();
	}

}
